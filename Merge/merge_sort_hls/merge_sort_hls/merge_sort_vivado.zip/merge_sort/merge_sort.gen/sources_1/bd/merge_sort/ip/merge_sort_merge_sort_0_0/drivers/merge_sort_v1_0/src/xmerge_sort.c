// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xmerge_sort.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMerge_sort_CfgInitialize(XMerge_sort *InstancePtr, XMerge_sort_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMerge_sort_Start(XMerge_sort *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMerge_sort_ReadReg(InstancePtr->Control_BaseAddress, XMERGE_SORT_CONTROL_ADDR_AP_CTRL) & 0x80;
    XMerge_sort_WriteReg(InstancePtr->Control_BaseAddress, XMERGE_SORT_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMerge_sort_IsDone(XMerge_sort *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMerge_sort_ReadReg(InstancePtr->Control_BaseAddress, XMERGE_SORT_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMerge_sort_IsIdle(XMerge_sort *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMerge_sort_ReadReg(InstancePtr->Control_BaseAddress, XMERGE_SORT_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMerge_sort_IsReady(XMerge_sort *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMerge_sort_ReadReg(InstancePtr->Control_BaseAddress, XMERGE_SORT_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMerge_sort_EnableAutoRestart(XMerge_sort *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMerge_sort_WriteReg(InstancePtr->Control_BaseAddress, XMERGE_SORT_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XMerge_sort_DisableAutoRestart(XMerge_sort *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMerge_sort_WriteReg(InstancePtr->Control_BaseAddress, XMERGE_SORT_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XMerge_sort_Get_input_r_BaseAddress(XMerge_sort *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XMERGE_SORT_CONTROL_ADDR_INPUT_R_BASE);
}

u32 XMerge_sort_Get_input_r_HighAddress(XMerge_sort *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XMERGE_SORT_CONTROL_ADDR_INPUT_R_HIGH);
}

u32 XMerge_sort_Get_input_r_TotalBytes(XMerge_sort *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XMERGE_SORT_CONTROL_ADDR_INPUT_R_HIGH - XMERGE_SORT_CONTROL_ADDR_INPUT_R_BASE + 1);
}

u32 XMerge_sort_Get_input_r_BitWidth(XMerge_sort *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMERGE_SORT_CONTROL_WIDTH_INPUT_R;
}

u32 XMerge_sort_Get_input_r_Depth(XMerge_sort *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMERGE_SORT_CONTROL_DEPTH_INPUT_R;
}

u32 XMerge_sort_Write_input_r_Words(XMerge_sort *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMERGE_SORT_CONTROL_ADDR_INPUT_R_HIGH - XMERGE_SORT_CONTROL_ADDR_INPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XMERGE_SORT_CONTROL_ADDR_INPUT_R_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XMerge_sort_Read_input_r_Words(XMerge_sort *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMERGE_SORT_CONTROL_ADDR_INPUT_R_HIGH - XMERGE_SORT_CONTROL_ADDR_INPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XMERGE_SORT_CONTROL_ADDR_INPUT_R_BASE + (offset + i)*4);
    }
    return length;
}

u32 XMerge_sort_Write_input_r_Bytes(XMerge_sort *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMERGE_SORT_CONTROL_ADDR_INPUT_R_HIGH - XMERGE_SORT_CONTROL_ADDR_INPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XMERGE_SORT_CONTROL_ADDR_INPUT_R_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XMerge_sort_Read_input_r_Bytes(XMerge_sort *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMERGE_SORT_CONTROL_ADDR_INPUT_R_HIGH - XMERGE_SORT_CONTROL_ADDR_INPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XMERGE_SORT_CONTROL_ADDR_INPUT_R_BASE + offset + i);
    }
    return length;
}

u32 XMerge_sort_Get_output_r_BaseAddress(XMerge_sort *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XMERGE_SORT_CONTROL_ADDR_OUTPUT_R_BASE);
}

u32 XMerge_sort_Get_output_r_HighAddress(XMerge_sort *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XMERGE_SORT_CONTROL_ADDR_OUTPUT_R_HIGH);
}

u32 XMerge_sort_Get_output_r_TotalBytes(XMerge_sort *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XMERGE_SORT_CONTROL_ADDR_OUTPUT_R_HIGH - XMERGE_SORT_CONTROL_ADDR_OUTPUT_R_BASE + 1);
}

u32 XMerge_sort_Get_output_r_BitWidth(XMerge_sort *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMERGE_SORT_CONTROL_WIDTH_OUTPUT_R;
}

u32 XMerge_sort_Get_output_r_Depth(XMerge_sort *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMERGE_SORT_CONTROL_DEPTH_OUTPUT_R;
}

u32 XMerge_sort_Write_output_r_Words(XMerge_sort *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMERGE_SORT_CONTROL_ADDR_OUTPUT_R_HIGH - XMERGE_SORT_CONTROL_ADDR_OUTPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XMERGE_SORT_CONTROL_ADDR_OUTPUT_R_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XMerge_sort_Read_output_r_Words(XMerge_sort *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMERGE_SORT_CONTROL_ADDR_OUTPUT_R_HIGH - XMERGE_SORT_CONTROL_ADDR_OUTPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XMERGE_SORT_CONTROL_ADDR_OUTPUT_R_BASE + (offset + i)*4);
    }
    return length;
}

u32 XMerge_sort_Write_output_r_Bytes(XMerge_sort *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMERGE_SORT_CONTROL_ADDR_OUTPUT_R_HIGH - XMERGE_SORT_CONTROL_ADDR_OUTPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XMERGE_SORT_CONTROL_ADDR_OUTPUT_R_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XMerge_sort_Read_output_r_Bytes(XMerge_sort *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMERGE_SORT_CONTROL_ADDR_OUTPUT_R_HIGH - XMERGE_SORT_CONTROL_ADDR_OUTPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XMERGE_SORT_CONTROL_ADDR_OUTPUT_R_BASE + offset + i);
    }
    return length;
}

void XMerge_sort_InterruptGlobalEnable(XMerge_sort *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMerge_sort_WriteReg(InstancePtr->Control_BaseAddress, XMERGE_SORT_CONTROL_ADDR_GIE, 1);
}

void XMerge_sort_InterruptGlobalDisable(XMerge_sort *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMerge_sort_WriteReg(InstancePtr->Control_BaseAddress, XMERGE_SORT_CONTROL_ADDR_GIE, 0);
}

void XMerge_sort_InterruptEnable(XMerge_sort *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMerge_sort_ReadReg(InstancePtr->Control_BaseAddress, XMERGE_SORT_CONTROL_ADDR_IER);
    XMerge_sort_WriteReg(InstancePtr->Control_BaseAddress, XMERGE_SORT_CONTROL_ADDR_IER, Register | Mask);
}

void XMerge_sort_InterruptDisable(XMerge_sort *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMerge_sort_ReadReg(InstancePtr->Control_BaseAddress, XMERGE_SORT_CONTROL_ADDR_IER);
    XMerge_sort_WriteReg(InstancePtr->Control_BaseAddress, XMERGE_SORT_CONTROL_ADDR_IER, Register & (~Mask));
}

void XMerge_sort_InterruptClear(XMerge_sort *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMerge_sort_WriteReg(InstancePtr->Control_BaseAddress, XMERGE_SORT_CONTROL_ADDR_ISR, Mask);
}

u32 XMerge_sort_InterruptGetEnabled(XMerge_sort *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMerge_sort_ReadReg(InstancePtr->Control_BaseAddress, XMERGE_SORT_CONTROL_ADDR_IER);
}

u32 XMerge_sort_InterruptGetStatus(XMerge_sort *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMerge_sort_ReadReg(InstancePtr->Control_BaseAddress, XMERGE_SORT_CONTROL_ADDR_ISR);
}


#include <stdio.h>
#include <stdint.h>

#ifndef MERGE_H
#define MERGE_H

#define DATA_SIZE 8

void merge_sort(uint8_t input[DATA_SIZE], uint8_t output[DATA_SIZE]);

#endif
